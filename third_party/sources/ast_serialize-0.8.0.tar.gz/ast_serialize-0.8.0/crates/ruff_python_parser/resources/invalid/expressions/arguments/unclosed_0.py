call(

def foo():
    pass