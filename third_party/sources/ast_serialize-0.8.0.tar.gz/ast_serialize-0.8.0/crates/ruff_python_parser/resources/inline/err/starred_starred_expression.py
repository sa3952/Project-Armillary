print(*
*[])
print(* *[])
