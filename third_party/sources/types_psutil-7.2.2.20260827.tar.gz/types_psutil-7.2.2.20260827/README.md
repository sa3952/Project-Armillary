## Typing stubs for psutil

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`psutil`](https://github.com/giampaolo/psutil) package. It can be used by type checkers
to check code that uses `psutil`. This version of
`types-psutil` aims to provide accurate annotations for
`psutil==7.2.2`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/psutil`](https://github.com/python/typeshed/tree/main/stubs/psutil)
directory.

This package was tested with the following type checkers:
* [mypy](https://www.mypy-lang.org/) 2.3.0
* [pyrefly](https://pyrefly.org/) 1.3.0.dev1
* [pyright](https://microsoft.github.io/pyright/) 1.1.411
* [ty](https://docs.astral.sh/ty/) 0.0.59

It was generated from typeshed commit
[`c10142fb9463b1dd0c581d3f08f4c01c5c08a09e`](https://github.com/python/typeshed/commit/c10142fb9463b1dd0c581d3f08f4c01c5c08a09e).